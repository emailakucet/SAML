# Cara Menjana Fail .APK Untuk Aplikasi QM AMTO No 16 Skuadron (GitHub)

Fail ini menyediakan **GitHub Actions workflow** (`.github/workflows/build-apk.yml`) agar fail **.APK** (`QM_B200T_AMTO_16Skn.apk`) boleh dijana secara automatik di awan GitHub tanpa perlu memasang Android Studio berat di PC/telefon.

## Langkah 1: Pastikan GitHub Pages Sudah Aktif
1. Pastikan fail utama aplikasi di repositori `emailakucet/SAML` dinamakan **`index.html`**.
2. Pastikan repositori bersifat **Public** dan **Settings > Pages > Branch: main** sudah aktif (`https://emailakucet.github.io/SAML/`).

## Langkah 2: Muat Naik Fail Workflow ke GitHub
1. Di dalam repositori GitHub `emailakucet/SAML`, buat folder dan fail:
   `.github/workflows/build-apk.yml`
2. Salin isi `build-apk.yml` dari pakej ZIP ini dan simpan (*Commit changes*).

## Langkah 3: Jana & Muat Turun Fail `.APK`
1. Buka tab **Actions** di repositori GitHub anda.
2. Pilih workflow **Build Signed Android APK (TWA)**.
3. Tekan **Run workflow** > **Run workflow**.
4. Setelah selesai (sekitar 2–3 minit), buka hasil *run* tersebut dan muat turun artifact **`QM_B200T_AMTO_16Skn_APK`** yang mengandungi fail **`QM_B200T_AMTO_16Skn.apk`**.
5. Pindahkan fail `.apk` ke telefon Android anda dan pasang (*Install*).
